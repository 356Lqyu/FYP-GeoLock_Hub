"""Verify this extracted E4 snapshot using only its own files."""
import hashlib
import json
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parents[1]
RUN_ID = '7f5ddab6c0f94b20adffc878d3a97217'
MANIFEST_SHA256 = '19793d403ce285dda2a95ab499e077533106ff823a21539bfd8b843f6f1ae464'


def checked(name, expected):
    relative = PurePosixPath(name)
    if relative.is_absolute() or '..' in relative.parts or '\\' in name or ':' in name:
        raise ValueError(f"Invalid snapshot path: {name}")
    path = ROOT.joinpath(*relative.parts)
    if path.resolve() != path or not path.is_file():
        raise ValueError(f"Missing or redirected snapshot path: {name}")
    data = path.read_bytes()
    if hashlib.sha256(data).hexdigest() != expected:
        raise ValueError(f"SHA-256 mismatch: {name}")
    return data


def main():
    manifest = json.loads(checked("experiments/e4/experiment_result/run_manifest.json", MANIFEST_SHA256))
    if manifest.get("run_id") != RUN_ID or manifest.get("status") != "completed":
        raise ValueError("Unexpected run ID or completion status")
    groups = (
        ("source_sha256", "", 86),
        ("input_sha256", "benchmark dataset/dataset/", 8),
        ("artifact_sha256", "experiments/e4/", 22),
    )
    for key, prefix, count in groups:
        entries = manifest[key]
        if len(entries) != count:
            raise ValueError(f"Unexpected inventory count: {key}")
        for name, digest in entries.items():
            checked(prefix + name, digest)
    print(f"Verified {RUN_ID}: 86 sources, 8 frozen inputs, 22 artifacts and the original manifest.")


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, KeyError) as error:
        raise SystemExit(f"E4 snapshot verification failed: {error}") from None
