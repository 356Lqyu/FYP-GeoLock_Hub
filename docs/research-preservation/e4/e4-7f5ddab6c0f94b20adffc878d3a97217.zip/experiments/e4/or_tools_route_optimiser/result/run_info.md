# Run information: OR-Tools route optimiser (proposed, current app)

| Item | Value |
| --- | --- |
| Run ID | 7f5ddab6c0f94b20adffc878d3a97217 |
| Run at | 2026-11-16T22:03:06+08:00 |
| Scenarios | 100 ROUTE_PLANNING snapshots (sealed, shared by all E4 methods) |
| Method | backend.routing.phase_b.optimizers.proposed -> backend/routing/optimizers/cp_sat.py (Google OR-Tools CP-SAT; the same callable the routing worker uses) |
| Execution policy | ExecutionConfig(fixed_cost_weight=1.0, distance_cost_weight=1.0, deterministic_seconds_per_pass=0.25) |
| Settings | 240 minute route, 10 min per stop, 360 minute lease, fixed cost 5 + 1 per km |
| Validator | backend.routing.phase_b.validate_plan (independent recomputation) |
| OR-Tools | 9.15.6755 |
| Python | 3.13.9 |
