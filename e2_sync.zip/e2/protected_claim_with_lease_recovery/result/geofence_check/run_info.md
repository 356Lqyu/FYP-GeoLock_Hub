# Run information: Geofence check of the proposed method

| Item | Value |
| --- | --- |
| Run at | 2026-11-10T13:30:23+08:00 |
| Pairs | 1100 NGO listing pairs in 100 scenarios |
| Right answer | benchmark road distance from NGO to pickup is 20 km or less, and a route exists |
| Decision | deployed geolock_ngo_listing_road_check() logic, road distance from the benchmark |
| Direct claims | every NGO that is not allowed also calls claim_listing() directly |
| Run ID | dad096ea66ef |
